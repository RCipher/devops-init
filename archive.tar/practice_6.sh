#!/bin/bash
i=0
while true; do
echo "second is $i"
mv 1 
sleep 2
done
